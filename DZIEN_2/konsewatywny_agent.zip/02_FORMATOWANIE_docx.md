# FORMATOWANIE DOKUMENTU DOCX
## Specyfikacja kanoniczna — plik wiedzy nr 2

Ten plik definiuje formatowanie każdego pliku .docx generowanego przez agenta.
Wartości można zmienić — wystarczy edytować ten plik i wgrać ponownie do wiedzy GPT.
Agent MUSI stosować te parametry przy każdej generacji pliku, używając skryptu z pliku wiedzy nr 3.

---

## 1. STRONA

| Parametr | Wartość |
|---|---|
| Format | A4 (21,0 × 29,7 cm) |
| Orientacja | pionowa |
| Margines górny | 2,5 cm |
| Margines dolny | 2,5 cm |
| Margines lewy | 3,0 cm |
| Margines prawy | 2,0 cm |

## 2. TYPOGRAFIA

| Element | Font | Rozmiar | Styl | Wyrównanie |
|---|---|---|---|---|
| Tytuł główny | Book Antiqua | 22 pt | pogrubiony, kapitaliki | do środka |
| Podtytuł / motto | Book Antiqua | 12 pt | kursywa | do środka |
| Tekst główny | Garamond (fallback: Book Antiqua) | 12 pt | normalny | wyjustowany |
| Sentencja beczkowa (wyróżniona) | Garamond | 13 pt | kursywa, pogrubiona | do środka |
| Stopka | Garamond | 9 pt | normalny | do środka |

## 3. AKAPITY

- Interlinia tekstu głównego: **1,4**
- Wcięcie pierwszego wiersza akapitu: **0,75 cm**
- Odstęp po akapicie: **6 pt**
- Sentencje beczkowe: wydzielone jako osobny akapit, odstęp przed i po: **12 pt**, bez wcięcia
- Tytuł: odstęp po: **18 pt**; podtytuł: odstęp po: **24 pt**

## 4. ELEMENTY OZDOBNE

- Pod tytułem i podtytułem: separator — linia ozdobna z trzech gwiazdek `❦ ❦ ❦` lub `✦ ✦ ✦` (Book Antiqua, 11 pt, do środka)
- Ten sam separator przed ostatnim akapitem (zatrzaskiem), jeśli tekst ma ponad 4 akapity
- Zero kolorów poza czernią; zero WordArt; zero ramek stron

## 5. STOPKA I NUMERACJA

- Stopka na każdej stronie: numer strony do środka, format: `— N —`
- Pierwsza strona: stopka również widoczna
- Brak nagłówka (header pusty)

## 6. METADANE PLIKU

- Tytuł dokumentu (properties): tytuł tekstu
- Autor (properties): wartość podana przez użytkownika; jeśli brak — pozostawić puste
- Nazwa pliku: tytuł tekstu zapisany małymi literami, spacje → podkreślniki, bez znaków diakrytycznych, np. `o_modach_wszelakich.docx`

## 7. STRUKTURA DOKUMENTU (kolejność)

1. Tytuł główny
2. Podtytuł lub motto (opcjonalnie — jeśli tekst go ma)
3. Separator ozdobny
4. Tekst główny (akapity; sentencje beczkowe jako wyróżnione akapity centralne)
5. Separator ozdobny (przy tekstach > 4 akapity)
6. Akapit końcowy — zatrzask

## 8. CZEGO NIE ROBIĆ

- Nie używać list punktowanych ani numerowanych w tekście literackim.
- Nie używać nagłówków H1/H2/H3 wewnątrz tekstu (to proza, nie raport).
- Nie wstawiać tabel, obrazów ani hiperłączy, chyba że użytkownik wyraźnie zażąda.
- Nie zostawiać w pliku żadnych komentarzy technicznych ani znaczników.
