# -*- coding: utf-8 -*-
"""
GENERATOR DOCX — plik wiedzy nr 3
Kanoniczny skrypt formatowania dla agenta "Rubaszny Konserwatysta".
Agent (Code Interpreter) MUSI używać tego skryptu do generowania plików .docx.
Implementuje w całości specyfikację z pliku 02_FORMATOWANIE_docx.md.

Użycie w Code Interpreterze:
    build_docx(
        title="O modach wszelakich",
        subtitle="rzecz o tym, jak nowinki stare głupstwa w nowe szaty ubierają",  # lub None
        paragraphs=[
            ("normal", "Pierwszy akapit tekstu..."),
            ("sentence", "Pusty wóz najgłośniej turkocze po bruku."),
            ("normal", "Kolejny akapit..."),
        ],
        author="",            # opcjonalnie
        out_dir="/mnt/data",  # w ChatGPT Code Interpreter
    )
"""

import re
import unicodedata
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT_MAIN = "Garamond"
FONT_TITLE = "Book Antiqua"
SEPARATOR = "\u2766 \u2766 \u2766"  # ❦ ❦ ❦


def _slugify(title: str) -> str:
    s = unicodedata.normalize("NFKD", title)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.replace("\u0142", "l").replace("\u0141", "L")  # ł/Ł
    s = re.sub(r"[^A-Za-z0-9 _-]", "", s).strip().lower()
    return re.sub(r"\s+", "_", s) or "tekst"


def _set_font(run, name=FONT_MAIN, size=12, bold=False, italic=False, small_caps=False):
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if small_caps:
        run.font.small_caps = True
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rFonts.set(qn(attr), name)


def _add_page_number_footer(section):
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r1 = p.add_run("\u2014 ")
    fld_begin = OxmlElement("w:fldChar"); fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = "PAGE"
    fld_end = OxmlElement("w:fldChar"); fld_end.set(qn("w:fldCharType"), "end")
    r2 = p.add_run(); r2._element.append(fld_begin); r2._element.append(instr); r2._element.append(fld_end)
    r3 = p.add_run(" \u2014")
    for r in (r1, r2, r3):
        _set_font(r, FONT_MAIN, 9)


def build_docx(title, paragraphs, subtitle=None, author="", out_dir="/mnt/data"):
    doc = Document()

    # --- strona: A4, marginesy ---
    sec = doc.sections[0]
    sec.orientation = WD_ORIENT.PORTRAIT
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin, sec.bottom_margin = Cm(2.5), Cm(2.5)
    sec.left_margin, sec.right_margin = Cm(3.0), Cm(2.0)

    # --- metadane ---
    doc.core_properties.title = title
    if author:
        doc.core_properties.author = author

    # --- tytuł ---
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    _set_font(p.add_run(title), FONT_TITLE, 22, bold=True, small_caps=True)

    # --- podtytuł / motto ---
    if subtitle:
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(24)
        _set_font(p.add_run(subtitle), FONT_TITLE, 12, italic=True)

    # --- separator ---
    def add_separator():
        sp = doc.add_paragraph(); sp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        sp.paragraph_format.space_before = Pt(6); sp.paragraph_format.space_after = Pt(12)
        _set_font(sp.add_run(SEPARATOR), FONT_TITLE, 11)

    add_separator()

    # --- treść ---
    normal_count = sum(1 for kind, _ in paragraphs if kind == "normal")
    last_normal_idx = max((i for i, (k, _) in enumerate(paragraphs) if k == "normal"), default=-1)

    for i, (kind, text) in enumerate(paragraphs):
        if kind == "sentence":
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            pf = p.paragraph_format
            pf.space_before = Pt(12); pf.space_after = Pt(12)
            pf.first_line_indent = Cm(0); pf.line_spacing = 1.4
            _set_font(p.add_run(text), FONT_MAIN, 13, bold=True, italic=True)
        else:
            # separator przed zatrzaskiem przy dłuższych tekstach
            if i == last_normal_idx and normal_count > 4:
                add_separator()
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            pf = p.paragraph_format
            pf.line_spacing = 1.4
            pf.first_line_indent = Cm(0.75)
            pf.space_after = Pt(6)
            _set_font(p.add_run(text), FONT_MAIN, 12)

    # --- stopka z numeracją ---
    _add_page_number_footer(sec)

    path = f"{out_dir}/{_slugify(title)}.docx"
    doc.save(path)
    return path
