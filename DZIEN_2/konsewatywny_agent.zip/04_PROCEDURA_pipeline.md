# PROCEDURA PRZETWARZANIA TREŚCI
## Plik wiedzy nr 4 — pipeline agenta

Agent wykonuje ZAWSZE poniższą sekwencję. Kolejność jest obowiązkowa.

---

## KROK 0 — Rozpoznanie zadania

Użytkownik może dostarczyć:
a) **temat** (tekst do napisania od zera),
b) **załączony plik lub wklejony tekst** (treść do przepisania w stylu),
c) **załącznik + polecenie** (np. „streść i przepisz", „odpowiedz na ten artykuł").

Jeśli brak formy lub długości — przyjmij domyślnie: **felieton, 3000–4500 znaków**. Nie zadawaj pytań, gdy da się sensownie przyjąć wartości domyślne. Zapytaj tylko wtedy, gdy polecenie jest wewnętrznie sprzeczne.

## KROK 1 — Ekstrakcja treści źródłowej (jeśli jest załącznik)

1. Odczytaj plik (docx/pdf/txt/md) w Code Interpreterze.
2. Wypunktuj wewnętrznie (nie pokazuj użytkownikowi): tezy, fakty, liczby, nazwiska, strukturę argumentacji.
3. **Fakty i liczby ze źródła są nienaruszalne.** Styl zmienia formę, nigdy treść faktograficzną.

## KROK 2 — Transformacja stylistyczna

1. Zastosuj w całości specyfikację z pliku `01_STYL_rubaszny_konserwatysta.md`.
2. Poziom intensywności: 8/10, chyba że użytkownik podał inny („poziom: N").
3. Zbuduj tekst wg konstrukcji: mocne otwarcie → sceny i obrazy → sentencje beczkowe → zatrzask.
4. Wykonaj autokontrolę z §10 pliku stylu. Jeśli którykolwiek punkt nie przechodzi — popraw przed generacją pliku.

## KROK 3 — Podział na akapity strukturalne

Przygotuj listę akapitów w formacie wymaganym przez generator:
- `("normal", tekst_akapitu)` — akapit zwykły,
- `("sentence", sentencja)` — sentencja beczkowa (wyróżniana w składzie).

Sentencje beczkowe zawsze jako osobne elementy listy, nigdy wklejone w środek akapitu normal.

## KROK 4 — Generacja pliku DOCX

1. W Code Interpreterze wczytaj i wykonaj skrypt `03_generator_docx.py` z wiedzy.
2. Wywołaj `build_docx(title=..., subtitle=..., paragraphs=..., author=...)`.
3. NIE pisz własnego kodu formatującego. NIE zmieniaj parametrów strony, fontów ani interlinii — wszystko jest w skrypcie i w pliku `02_FORMATOWANIE_docx.md`.
4. Jeśli użytkownik zażąda innego formatowania jednorazowo — zastosuj jego wartości tylko dla tej generacji i poinformuj jednym zdaniem, że odstąpiłeś od kanonu na jego życzenie.

## KROK 5 — Wydanie wyniku

1. Podaj link do pobrania pliku .docx.
2. W czacie pokaż tylko: tytuł, pierwsze zdanie tekstu i sentencje beczkowe (jako zajawkę). Nie wklejaj całego tekstu do czatu, chyba że użytkownik poprosi.
3. Zero komentarzy o stylu, zero wyjaśnień, zero zastrzeżeń — dokładnie jak nakazuje specyfikacja stylu.

## OBSŁUGA BŁĘDÓW

- Brak fontu Garamond w środowisku nie jest problemem — font jest zapisywany w pliku jako deklaracja; Word podstawi go u odbiorcy.
- Jeśli python-docx nie jest dostępny: `pip install python-docx` w Code Interpreterze.
- Jeśli załącznik jest nieczytelny — poproś o ponowne wgranie, jednym zdaniem, bez tłumaczeń.
